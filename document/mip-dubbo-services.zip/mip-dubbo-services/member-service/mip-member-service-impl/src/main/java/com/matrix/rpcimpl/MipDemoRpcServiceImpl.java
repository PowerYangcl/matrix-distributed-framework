package com.matrix.rpcimpl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;

import com.matrix.base.BaseClass;
import com.matrix.base.interfaces.IBaseCache;
import com.matrix.dao.IMemberInfoMapper;
import com.matrix.dict.LoadCacheTest;
import com.matrix.pojo.entity.MemberInfo;
import com.matrix.rpc.IMipDemoRpcService;


@Service("mipDemoRpcService")
public class MipDemoRpcServiceImpl extends BaseClass implements IMipDemoRpcService {

	private static Logger logger = Logger.getLogger(MipDemoRpcServiceImpl.class);
			
	@Resource
	private IMemberInfoMapper memberInfoMapper;
	
	/**
	 * @description: 关于如何使用系统配置文件和国际化消息提示信息
	 * 	文件存储路径为：
	 * 			1、配置文件：META-INF/matrix/config/config.mip-member.properties
	 * 			2、消息提示：META-INF/matrix/config/info.mip-member.9010.properties
	 *
	 * @author Yangcl
	 * @date 2018年9月14日 下午3:56:00 
	 * @version 1.0.0.1
	 */
	public String mipDemo() {
		// 返回配置文件：config.mip-member.properties中的配置文件信息【a:demo_upload_dev】;this.getConfig("matrix-core.model")返回的配置是：dev
		String demoConfig = this.getConfig("mip-member.demo_upload_" + this.getConfig("matrix-core.model"));
		// 返回配置文件：info.mip-member.9010.properties中的提示消息【mip-member-service:查询结构集为空，没有可以显示的数据】
		String demoInfo = this.getInfo(90100002);	
		
		List<MemberInfo> findList = memberInfoMapper.findList(null);
		if(memberInfoMapper != null) {
			this.getLogger(logger).logInfo("member info list size = " + findList.size());
		}
		
		
		IBaseCache cache = new LoadCacheTest();
		cache.refresh();
		
		
		if(StringUtils.isAnyBlank(demoConfig , demoInfo)) {
			return "Hello Man !";
		}
		
		return demoConfig + "@" + demoInfo; 
	}

}





















