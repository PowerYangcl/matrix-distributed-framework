package com.matrix.service;

/**
 * @author WangJu
 * @version 1.0.0.1
 * @description:
 * @date 2018-09-14 10:23
 */
public interface IMemberInfoService{
}
