package com.matrix.dao;

import com.matrix.base.interfaces.IBaseDao;
import com.matrix.pojo.dto.MemberInfoDto;
import com.matrix.pojo.entity.MemberInfo;
import com.matrix.pojo.view.MemberInfoView;

public interface IMemberInfoMapper extends IBaseDao<Long,MemberInfo,MemberInfoDto,MemberInfoView> {
}