package com.matrix.service.impl;

import com.matrix.service.IMemberInfoService;
import org.springframework.stereotype.Service;

/**
 * @author WangJu
 * @version 1.0.0.1
 * @description:
 * @date 2018-09-14 10:54
 */
@Service("memberInfoService")
public class MemberInfoServiceImpl implements IMemberInfoService {
}
