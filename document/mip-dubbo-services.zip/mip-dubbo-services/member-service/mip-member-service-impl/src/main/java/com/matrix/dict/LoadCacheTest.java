package com.matrix.dict;

import java.util.List;

import org.apache.log4j.Logger;

import com.matrix.annotation.Inject;
import com.matrix.base.BaseClass;
import com.matrix.base.interfaces.IBaseCache;
import com.matrix.dao.IMemberInfoMapper;
import com.matrix.pojo.entity.MemberInfo;

public class LoadCacheTest  extends BaseClass implements IBaseCache {

	private static Logger logger = Logger.getLogger(LoadCacheTest.class);
	
	
	@Inject
	private IMemberInfoMapper memberInfoMapper;
	
	@Override
	public void refresh() {
		List<MemberInfo> findList = memberInfoMapper.findList(null);
		if(memberInfoMapper != null) {
			this.getLogger(logger).logInfo("member info list size = " + findList.size());
		}
	}

	@Override
	public void removeAll() {
	}

}
