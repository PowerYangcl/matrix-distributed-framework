package com.matrix.rpc;

public interface IMipDemoRpcService {

	/**
	 * @description: 关于如何使用系统配置文件和国际化消息提示信息
	 * 	文件存储路径为：
	 * 			1、配置文件：META-INF/matrix/config/config.mip-member.properties
	 * 			2、消息提示：META-INF/matrix/config/info.mip-member.9010.properties
	 *
	 * @author Yangcl
	 * @date 2018年9月14日 下午3:56:00 
	 * @version 1.0.0.1
	 */
	public String mipDemo();
}
