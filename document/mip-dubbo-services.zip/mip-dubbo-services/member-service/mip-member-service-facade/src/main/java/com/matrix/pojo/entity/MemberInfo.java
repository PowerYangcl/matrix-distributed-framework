package com.matrix.pojo.entity;

import com.matrix.base.BaseEntity;

import java.io.Serializable;
import java.util.Date;

public class MemberInfo extends BaseEntity implements Serializable {

    private static final long serialVersionUID = 270746639883822402L;
    /** 会员基本信息表id*/
    private Long id;

    /** 公司id*/
    private Integer cid;

    /** 创建时间*/
    private Date createTime;

    /** 创建人id*/
    private Long createUserId;

    /** 创建人姓名*/
    private String createUserName;

    /** 更新时间*/
    private Date updateTime;

    /** 更新人id*/
    private Long updateUserId;

    /** 更新者姓名*/
    private String updateUserName;

    /** 删除标记: 0删除|1未删除*/
    private Integer deleteFlag;

    /** 注册门店id*/
    private Long storeInfoId;

    /** 用户名*/
    private String account;

    /** 密码*/
    private String password;

    /** 昵称*/
    private String nickName;

    /** 手机*/
    private String phone;

    /** 邮箱*/
    private String email;

    /** 性别：1男 2女 0 默认*/
    private Integer sex;

    /** 生日*/
    private Date birthday;

    /** 头像*/
    private String headPic;

    /** 身份证号*/
    private String idCard;

    /** 会员状态。1：正常；2：冻结*/
    private Integer isFreezing;

    /** 0普通会员 1付费会员|冗余dict_member_level_info字段，减少联查*/
    private Integer memberType;

    /** 如果为付费会员，此处为有效期开始时间*/
    private Date startTime;

    /** 如果为付费会员，此处为有效期结束时间*/
    private Date endTime;

    /** qq*/
    private String qq;

    /** 微信*/
    private String wechart;

    /** 微博*/
    private String weibo;

    /** 推荐人id，为这张表里存在的记录*/
    private Long recommendUserId;

    /** 会员信息来源渠道*/
    private Long dictSourceChannelInfoId;

    /** 收入范围|月收入水平|主键*/
    private Long dictIncomeRangeInfoId;

    /** 行业划分表主键*/
    private Long dictVocationInfoId;

    /** 教育程度表主键*/
    private Long dictEducationLevelInfoId;

    /** 会员等级字典*/
    private Long dictMemberLevelInfoId;

    /** 省/直辖市id*/
    private String provinceId;

    /** 市/市辖区id*/
    private String cityId;

    /** 县/区 id*/
    private String areaId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Integer getCid() {
        return cid;
    }

    public void setCid(Integer cid) {
        this.cid = cid;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(Long createUserId) {
        this.createUserId = createUserId;
    }

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName == null ? null : createUserName.trim();
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }

    public Long getUpdateUserId() {
        return updateUserId;
    }

    public void setUpdateUserId(Long updateUserId) {
        this.updateUserId = updateUserId;
    }

    public String getUpdateUserName() {
        return updateUserName;
    }

    public void setUpdateUserName(String updateUserName) {
        this.updateUserName = updateUserName == null ? null : updateUserName.trim();
    }

    public Integer getDeleteFlag() {
        return deleteFlag;
    }

    public void setDeleteFlag(Integer deleteFlag) {
        this.deleteFlag = deleteFlag;
    }

    public Long getStoreInfoId() {
        return storeInfoId;
    }

    public void setStoreInfoId(Long storeInfoId) {
        this.storeInfoId = storeInfoId;
    }

    public String getAccount() {
        return account;
    }

    public void setAccount(String account) {
        this.account = account == null ? null : account.trim();
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password == null ? null : password.trim();
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName == null ? null : nickName.trim();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone == null ? null : phone.trim();
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email == null ? null : email.trim();
    }

    public Integer getSex() {
        return sex;
    }

    public void setSex(Integer sex) {
        this.sex = sex;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    public String getHeadPic() {
        return headPic;
    }

    public void setHeadPic(String headPic) {
        this.headPic = headPic == null ? null : headPic.trim();
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard == null ? null : idCard.trim();
    }

    public Integer getIsFreezing() {
        return isFreezing;
    }

    public void setIsFreezing(Integer isFreezing) {
        this.isFreezing = isFreezing;
    }

    public Integer getMemberType() {
        return memberType;
    }

    public void setMemberType(Integer memberType) {
        this.memberType = memberType;
    }

    public Date getStartTime() {
        return startTime;
    }

    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    public Date getEndTime() {
        return endTime;
    }

    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq == null ? null : qq.trim();
    }

    public String getWechart() {
        return wechart;
    }

    public void setWechart(String wechart) {
        this.wechart = wechart == null ? null : wechart.trim();
    }

    public String getWeibo() {
        return weibo;
    }

    public void setWeibo(String weibo) {
        this.weibo = weibo == null ? null : weibo.trim();
    }

    public Long getRecommendUserId() {
        return recommendUserId;
    }

    public void setRecommendUserId(Long recommendUserId) {
        this.recommendUserId = recommendUserId;
    }

    public Long getDictSourceChannelInfoId() {
        return dictSourceChannelInfoId;
    }

    public void setDictSourceChannelInfoId(Long dictSourceChannelInfoId) {
        this.dictSourceChannelInfoId = dictSourceChannelInfoId;
    }

    public Long getDictIncomeRangeInfoId() {
        return dictIncomeRangeInfoId;
    }

    public void setDictIncomeRangeInfoId(Long dictIncomeRangeInfoId) {
        this.dictIncomeRangeInfoId = dictIncomeRangeInfoId;
    }

    public Long getDictVocationInfoId() {
        return dictVocationInfoId;
    }

    public void setDictVocationInfoId(Long dictVocationInfoId) {
        this.dictVocationInfoId = dictVocationInfoId;
    }

    public Long getDictEducationLevelInfoId() {
        return dictEducationLevelInfoId;
    }

    public void setDictEducationLevelInfoId(Long dictEducationLevelInfoId) {
        this.dictEducationLevelInfoId = dictEducationLevelInfoId;
    }

    public Long getDictMemberLevelInfoId() {
        return dictMemberLevelInfoId;
    }

    public void setDictMemberLevelInfoId(Long dictMemberLevelInfoId) {
        this.dictMemberLevelInfoId = dictMemberLevelInfoId;
    }

    public String getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(String provinceId) {
        this.provinceId = provinceId == null ? null : provinceId.trim();
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId == null ? null : cityId.trim();
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId == null ? null : areaId.trim();
    }
}