package com.matrix.pojo.view;

import com.matrix.base.BaseView;

import java.io.Serializable;

public class MemberInfoView extends BaseView implements Serializable {

    private static final long serialVersionUID = 8788055410517509532L;

}