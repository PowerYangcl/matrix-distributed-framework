/**
 * Created by Administrator on 2016/8/22.
 */




var inFrame = ( (self.frameElement && self.frameElement.tagName)=="IFRAME" );
if( inFrame){
    $("header.container").hide();
    $("nav.nav-top").hide();
    $("nav.nav-left").hide();
    $("ul.link-tabs").hide();
    $("section.container").removeClass("container").removeClass("navleft");
}

$(function(){
    // 设置顶部菜单
    var setTopNav = function( navList ){
        if( 0 && sessionStorage.getItem("tempTopNav") ){
            return false;
        }
        var lis = [];
        $.each(navList, function( key, item ){
            lis.push('<li d-name="'+key+'" id="nav_top_'+item.id+'">',
                '<a href="'+(item.menu && item.menu[0].items? item.menu[0].items[0].href :
                    ( item.menu && item.menu[0].href ? item.menu[0].href : 'javascript:void(0);'))+'">' +item.text+ '</a></li>');
        });
        $(".nav-top>ul.nav-tabs").html( lis.join("") );
        sessionStorage.setItem( "tempTopNav", lis.join("") );
    }
    setTopNav(navList);
    // 设置左侧菜单
    var setLeftNav = function( curNav ){
        if( curNav.labelnav ){
            $("section.container").removeClass("navleft");
            return false;
        }
        var lis = [];
        var navList = curNav.menu;
        $.each(navList, function( gKey, gItem ){
            lis.push('<li><div class="nav-group-title">',
                (gItem.href? '': '<i class="icon-arrow"></i>'),
                '<i class="incon-nav incon-nav-'+gItem.id+'"></i>',
                '<a href="'+(gItem.href? gItem.href: 'javascript:void(0);')+'">'+ gItem.text +'</a></div>');
            if( gItem.items && gItem.items.length ){
                lis.push('<ul class="nav-list">');
                $.each(gItem.items, function( lKey, lItem ){
                    lis.push('<li id="nav_left_'+lItem.id+'">',
                        '<a href="'+(lItem.href? lItem.href: 'javascript:void(0);')+'"><span>' +lItem.text+ '<span></a></li>');
                });
                lis.push('</ul>');
            }
            lis.push('</li>');
        });
        $(".nav-left>ul.nav-group").html( lis.join("") );
        sessionStorage.setItem( "tempLeftNav", lis.join("") );
    }

    // 设置当前菜单
    var setCurActive = function( navList, parentArr ){
        var mappingStr = window.location.href.toLocaleLowerCase();
        $.each(mappingUrl, function( org, rel ){
            if( org && (mappingStr).indexOf(org.toLocaleLowerCase())>=0 ){
                mappingStr += '=' + rel.toLocaleLowerCase();
            }
        });
        $.each(navList, function( key, item ){
            if( item.href && (mappingStr).indexOf(item.href.toLocaleLowerCase())>=0 ){
                parentArr.push(item);
                parentArr.push("done");
                window["tempCurNav"] = null;
                return false;
            }
            if( item.menu && item.menu.length ){
                parentArr.push(item);
                setCurActive( item.menu, parentArr );
            }
            if( item.items && item.items.length ){
                parentArr.push(item);
                setCurActive( item.items, parentArr );
            }
        });
        if( parentArr.pop()=="done" && parentArr.length ){
            setLeftNav( parentArr[0] );
            window["tempCurNav"] = parentArr[0] ;
            $.each(parentArr, function(index,item){
                //console.log($("#nav_left_"+item.id));
                $("#nav_top_"+item.id).addClass("active");
                $("#nav_left_"+item.id).addClass("active");
                $("#nav_left_"+item.id).parent().closest("li").addClass("active");
                $(".incon-nav-"+item.id).closest("li").addClass("active");
            });
            return false;
        }else{
            window["tempCurNav"] && !$(".nav-left>ul.nav-group").html() && setLeftNav( window["tempCurNav"] );
        }
    }
    setCurActive(navList,[]);
    // 绑定菜单事件
    var bindNavEvent = function(){
        $(".nav-group-title").click(function(){
            // $(".nav-group>li").removeClass('active');
            // $(this).parent().addClass('active');
            $(this).parent().toggleClass('active');
            var href = $(this).find("a").attr("href");
            if( href!="javascript:void(0);" ){
                href = $("head base").attr("href") + href;
                window.location.href = href;
            }
        });
        $(".link-tabs>li").click(function(){
            $(this).addClass('active').siblings().removeClass('active');
        });
    }
    bindNavEvent();
    !!$.trim($("nav.nav-left").text()) && $("nav.nav-left").css("minHeight", $(window).height()-143+"px");

    setTimeout(function(){ $(".loading").fadeOut(); },0);

    BUI.use('bui/overlay',function(Overlay){
        var alertSetting = {
            title:'系统提示',
            width:310,
            height:130,
            mask:true,  //设置是否模态
            closeable : false,
            elCls : 'sys-notice-style',
            bodyContent:''
        };

        var formatVal = function(val){
            // val = typeof val=='string' ? val : '{{!}} 注意了  O o 。.';
            val = val.replace('{{v}}','<i class="ico ico-right"></i>');
            val = val.replace('{{!}}','<i class="ico ico-notice"></i>');
            return val;
        }

        $.alert = function(val,call){
            if(typeof val=="string"){
                var alertDialog = new Overlay.Dialog( alertSetting );
                alertDialog.set("bodyContent", formatVal(val) );
                alertDialog.set("buttons", [{
                    text:'确定',
                    elCls : 'but-blue',
                    handler : function(){
                        (typeof call=="function") && call();
                        this.close();
                        $(".bui-ext-mask").css("z-index","1040")
                    }
                }]);
                alertDialog.show();
                $(".bui-ext-mask").css("z-index","88888")
            }else{

            }
        }

        $.confirm = function(val,call,call2){
            if(typeof val=="string"){
                var alertDialog = new Overlay.Dialog( alertSetting );
                alertDialog.set("bodyContent", formatVal(val) );
                alertDialog.set("buttons", [{
                    text:'确定',
                    elCls : 'but-blue',
                    handler : function(){
                        (typeof call=="function") && call();
                        this.close();
                    }
                },{
                    text:'取消',
                    elCls : 'but-wire-blue',
                    handler : function(){
                        (typeof call2=="function") && call2();
                        this.close();
                    }
                }]);
                alertDialog.show();
            }else{

            }
        }

        $.note = function(val,call){
            if(typeof val=="string"){
                var alertDialog = new Overlay.Dialog( alertSetting );
                alertDialog.set("bodyContent", formatVal(val) );
                alertDialog.set("buttons", []);
                alertDialog.show();
                setTimeout(function(){
                    if(typeof call=="function" ){
                        alertDialog.close();
                        call();
                    }else if(typeof call=="string" ){
                        window.location.href = call;
                    }
                }, 1*1000);
            }else{

            }
        }

    });

})