package cn.face.oms.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.alibaba.dubbo.common.Constants;
import com.alibaba.dubbo.common.URL;

import cn.face.oms.pojo.dto.ApplicationDto;
import cn.face.oms.pojo.view.ProviderView;
import cn.face.oms.service.AbstractDubboAdminService;
import cn.face.oms.service.IAdminProviderService;
import cn.face.oms.utils.Pair;
import cn.face.oms.utils.SyncUtils;


/**
 * @description: dubbo admin provider service
 *
 * @author Yangcl
 * @date 2018年8月27日 上午11:44:17 
 * @version 1.0.0.1
 */
@Service("adminProviderService")
public class AdminProviderServiceImpl extends AbstractDubboAdminService implements IAdminProviderService {

	
	/**
	 * @description: 查询某个应用提供的所有服务信息
	 *
	 * @param dto.application 	服务名称
	 * @author Yangcl
	 * @date 2018年8月29日 下午5:15:52 
	 * @version 1.0.0.1
	 */
	public List<ProviderView> listProviderByApplication(ApplicationDto dto) {
		
		return super.filterCategoryData(
				new ConvertURL2Entity<ProviderView>() {
		            public ProviderView convert(Pair<Long, URL> pair) {
		            	
		                return SyncUtils.url2Provider(pair);
		            }
				} ,
				Constants.PROVIDERS_CATEGORY  , 	// providers
				Constants.APPLICATION_KEY  , 			// application
				dto.getApplication()
			);
	}

}






































