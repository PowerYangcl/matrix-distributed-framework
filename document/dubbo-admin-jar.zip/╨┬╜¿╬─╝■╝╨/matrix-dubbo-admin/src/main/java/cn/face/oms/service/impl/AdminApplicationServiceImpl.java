package cn.face.oms.service.impl;

import cn.face.oms.pojo.dto.ApplicationDto;
import cn.face.oms.pojo.view.ApplicationView;
import cn.face.oms.pojo.view.ConsumerView;
import cn.face.oms.pojo.view.Node;
import cn.face.oms.pojo.view.ProviderView;
import cn.face.oms.service.AbstractDubboAdminService;
import cn.face.oms.service.IAdminApplicationService;
import cn.face.oms.service.IAdminConsumerService;
import cn.face.oms.service.IAdminOverrideService;
import cn.face.oms.service.IAdminProviderService;

import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import com.alibaba.dubbo.common.Constants;
import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.monitor.MonitorService;
import com.alibaba.fastjson.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentMap;

import javax.annotation.Resource;

/**
 * @description: dubbo admin application service
 *
 * @author Yangcl
 * @date 2018年8月27日 上午11:44:17 
 * @version 1.0.0.1
 */
@Service("adminApplicationService")
public class AdminApplicationServiceImpl extends AbstractDubboAdminService implements IAdminApplicationService {

	@Resource
	private IAdminProviderService adminProviderService;
	@Resource
	private IAdminConsumerService adminConsumerService;
	@Resource
	private IAdminOverrideService adminOverrideService;
	
	
	
	
	/**
	 * @description:  查询所有应用列表信息
	 *
	 * @param dto
	 * @author Yangcl
	 * @date 2018年8月27日 下午5:15:30 
	 * @version 1.0.0.1
	 */
	public JSONObject ajaxFindApplicationList(ApplicationDto dto) {
		JSONObject result = new JSONObject();
		
		List<ApplicationView> applicationList = new ArrayList<ApplicationView>();
		
		ConcurrentMap<String, Map<Long, URL>> providers = getServiceByCategory(Constants.PROVIDERS_CATEGORY);			// providers
        if(providers != null){
            for(Map.Entry<String, Map<Long, URL>> oneService:providers.entrySet()){
                Map<Long, URL> urls = oneService.getValue();
                for(Map.Entry<Long,URL> url : urls.entrySet()){
                    ApplicationView view = new ApplicationView();
                    view.setApplication(url.getValue().getParameter(Constants.APPLICATION_KEY));
                    view.setUsername(url.getValue().getParameter("owner"));
                    view.setType(view.PROVIDER);
                    if(!applicationList.contains(view)){
                        applicationList.add(view);
                    }
                    break;
                }
            }
        }
        
        ConcurrentMap<String, Map<Long, URL>> consumers = getServiceByCategory(Constants.CONSUMERS_CATEGORY);		// consumers
        if(consumers != null){
            for(Map.Entry<String, Map<Long, URL>> oneService:consumers.entrySet()){
                //某个服务的所有地址，一个服务可能会被多个应用消费
                Map<Long, URL> urls = oneService.getValue();
                for(Map.Entry<Long,URL> url : urls.entrySet()){
                    if(url.getValue().getParameter(Constants.INTERFACE_KEY).equals( MonitorService.class.getName() )){     // 检索dubbo MonitorService服务信息
                        continue;
                    }
                    
                    ApplicationView view = new ApplicationView();
                    view.setApplication(url.getValue().getParameter(Constants.APPLICATION_KEY));
                    view.setUsername(url.getValue().getParameter("owner"));
                    if(!applicationList.contains(view)){
                        view.setType(view.CONSUMER);   // 标记为消费者
                        applicationList.add(view);
                    }else{
                        view=applicationList.get(applicationList.indexOf(view));
                        if(view.getType()==view.PROVIDER){
                            view.setType(view.PROVIDER_AND_CONSUMER);  // 标记为提供者和消费者
                        }
                    }
                    
                }
            }
        }
		
        result.put("status", "success");
        if(StringUtils.isBlank(dto.getApplication()) && StringUtils.isBlank(dto.getUsername()) && dto.getType() == null) {
        	result.put("list", applicationList);
        	return result;
        }
		
        List<ApplicationView> list = new ArrayList<ApplicationView>();
        for(ApplicationView v : applicationList) {
        	if(StringUtils.isNotBlank(dto.getApplication()) && StringUtils.isNotBlank(dto.getUsername()) && dto.getType() != null) {
        		if( v.getApplication().equals(dto.getApplication()) && v.getUsername().equals(dto.getUsername()) && v.getType() == dto.getType() ) {
        			list.add(v);
        		}
        		continue;
        	}
        	if(StringUtils.isNotBlank(dto.getApplication()) && StringUtils.isNotBlank(dto.getUsername()) && dto.getType() == null) {
        		if( v.getApplication().equals(dto.getApplication()) && v.getUsername().equals(dto.getUsername()) ) {
        			list.add(v);
        		}
        		continue;
        	}
        	if(StringUtils.isNotBlank(dto.getApplication()) && StringUtils.isBlank(dto.getUsername()) && dto.getType() == null) {
        		if(v.getApplication().equals(dto.getApplication())) {
        			list.add(v);
        		}
        		continue;
        	}
        	if(StringUtils.isNotBlank(dto.getApplication()) && StringUtils.isBlank(dto.getUsername()) && dto.getType() != null) {
        		if( v.getApplication().equals(dto.getApplication()) && v.getType() == dto.getType() ) {
        			list.add(v);
        		}
        		continue;
        	}
        	if(StringUtils.isBlank(dto.getApplication()) && StringUtils.isNotBlank(dto.getUsername()) && dto.getType() != null) {
        		if( v.getUsername().equals(dto.getUsername()) && v.getType() == dto.getType() ) {
        			list.add(v);
        		}
        		continue;
        	}
        	if(StringUtils.isBlank(dto.getApplication()) && StringUtils.isNotBlank(dto.getUsername()) && dto.getType() == null) {
        		if(v.getUsername() != null && v.getUsername().equals(dto.getUsername()) ) {
        			list.add(v);
        		}
        		continue;
        	}
        	if(StringUtils.isBlank(dto.getApplication()) && StringUtils.isBlank(dto.getUsername()) && dto.getType() != null) {
        		if( v.getType() == dto.getType() ) {
        			list.add(v);
        		}
        		continue;
        	}
        }
		
        result.put("list", list);
		return result;
	}

	
	
	/**
	 * @description: Dubbo项目部署节点列表数据集合
	 *
	 * @param dto.application 	服务名称
	 * @author Yangcl
	 * @date 2018年8月29日 下午5:08:51 
	 * @version 1.0.0.1
	 */
	public JSONObject ajaxFindDubboProjectIpList(ApplicationDto dto) {
		JSONObject result = new JSONObject();
		if(StringUtils.isBlank(dto.getApplication())) {
			result.put("status", "error");
			result.put("msg", "Dubbo服务名称不可为空");
			return result;
		}
		
		List<ProviderView> providerList = adminProviderService.listProviderByApplication(dto); 
		List<ConsumerView> consumerList = adminConsumerService.listConsumerByApplication(dto);
		
		List<Node> nodeList = new ArrayList<Node>();
		for(ProviderView provider : providerList){
            Node node = new Node();
            node.setNodeAddress(provider.getAddress());
            node.setId(provider.getId());
            node.setType("生产者"); 
            if(!nodeList.contains(node)){
                nodeList.add(node);
            }
        }
        for(ConsumerView consumer : consumerList){
            Node node = new Node();
            node.setNodeAddress(consumer.getAddress());
            node.setId(consumer.getId());
            node.setType("消费者"); 
            if(!nodeList.contains(node)){
                nodeList.add(node);
            }
        }
        
        result.put("status", "success");
        if(StringUtils.isBlank( dto.getNodeAddress() )) {
        	result.put("list" , nodeList);
        	return result;
        }
        
        List<Node> list = new ArrayList<Node>();
        for(Node n : nodeList) {
        	if(StringUtils.contains(n.getNodeAddress() , dto.getNodeAddress())) {
        		list.add(n);
        	}
        }
        
        result.put("list" , list);
		return result;
	}



	/**
	 * @description:  Dubbo项目指定部署节点下的RPC接口类列表集合|jsp页面数据集合
	 *
	 * @param dto.application 	服务名称					必填
	 * @param dto.nodeAddress 	host ip address		必填
	 * 
	 * @author Yangcl
	 * @date 2018年8月30日 下午3:28:14 
	 * @version 1.0.0.1
	 */
	public JSONObject ajaxFindDubboProjectInterfaceList(ApplicationDto dto) {
		JSONObject result = new JSONObject();
		if(StringUtils.isBlank(dto.getApplication()) || StringUtils.isBlank(dto.getNodeAddress())) {
			result.put("status", "error");
			result.put("msg", "Dubbo服务名称和主机地址不可为空");
			return result;
		}
		
		List<ProviderView> providerList = new ArrayList<ProviderView>();  // 过滤后的集合
		
		List<ProviderView> providers = adminProviderService.listProviderByApplication(dto); 
		Iterator<ProviderView> iterator = providers.iterator();
        while(iterator.hasNext()){
        	ProviderView provider = iterator.next();
            if( !provider.getAddress().equals(dto.getNodeAddress()) ){
                iterator.remove();
            }else{
                providerList.add( adminOverrideService.configProvider(provider) );
            }
        }
		
        result.put("status", "success");
		
		if(StringUtils.isBlank(dto.getServiceKey()) && dto.getDynamic() == null && dto.getEnabled() == null) {
			result.put("list", providerList);  
			return result;
		}
		
		List<ProviderView> list = new ArrayList<ProviderView>();
		for(ProviderView v : providerList) {
			if(StringUtils.isNotBlank(dto.getServiceKey()) && dto.getDynamic() != null && dto.getEnabled() != null) {
				if(StringUtils.contains(v.getServiceKey() , dto.getServiceKey()) && dto.getDynamic() == v.isDynamic() && dto.getEnabled() == v.isEnabled()) {
					list.add(v);
				}
			}
			if(StringUtils.isNotBlank(dto.getServiceKey()) && dto.getDynamic() != null && dto.getEnabled() == null) {
				if(StringUtils.contains(v.getServiceKey() , dto.getServiceKey()) && dto.getDynamic() == v.isDynamic() ) {
					list.add(v);
				}
			}
			if(StringUtils.isNotBlank(dto.getServiceKey()) && dto.getDynamic() == null && dto.getEnabled() == null) {
				if(StringUtils.contains(v.getServiceKey() , dto.getServiceKey())) {
					list.add(v);
				}
			}
			if(StringUtils.isNotBlank(dto.getServiceKey()) && dto.getDynamic() == null && dto.getEnabled() != null) {
				if(StringUtils.contains(v.getServiceKey() , dto.getServiceKey())  && dto.getEnabled() == v.isEnabled()) {
					list.add(v);
				}
			}
			
			if(StringUtils.isBlank(dto.getServiceKey()) && dto.getDynamic() != null && dto.getEnabled() != null) {
				if( dto.getDynamic() == v.isDynamic() && dto.getEnabled() == v.isEnabled()) {
					list.add(v);
				}
			}
			if(StringUtils.isBlank(dto.getServiceKey()) && dto.getDynamic() != null && dto.getEnabled() == null) {
				if( dto.getDynamic() == v.isDynamic()) {
					list.add(v);
				}
			}
			if(StringUtils.isBlank(dto.getServiceKey()) && dto.getDynamic() == null && dto.getEnabled() != null) {
				if( dto.getEnabled() == v.isEnabled() ) {
					list.add(v);
				}
			}
		}
		
		
		result.put("list", list);  
		return result;
	}


	
	
	
}


































