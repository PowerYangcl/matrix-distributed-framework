package cn.face.oms.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;

import cn.face.oms.pojo.dto.ApplicationDto;
import cn.face.oms.service.IAdminApplicationService;

/**
 * @description: dubbo 服务控制层
 *
 * @author Yangcl
 * @date 2018年8月27日 上午11:49:34 
 * @version 1.0.0.1
 */
@Controller
@RequestMapping("/application")
public class ApplicationController {

	@Autowired
	private IAdminApplicationService adminApplicationService;
	
	
	
	/**
	 * @description: Dubbo应用服务列表|Dubbo项目名称列表
	 *
	 * @param session
	 * @author Yangcl
	 * @date 2018年8月29日 下午3:06:09 
	 * @version 1.0.0.1
	 */
	@RequestMapping("page_application_dubbo_project_list")
	public String pageApplicationDubboProjectList(HttpSession session){
		return "dubbo/admin/dubbo-project-list";
	}
	
	/**
	 * @description:  查询所有应用列表信息
	 *			http://oms.ostar.com:8080/ostar-oms/application/ajaxFindApplicationList
	 *
	 * @param dto
	 * @author Yangcl
	 * @date 2018年8月27日 下午5:15:30 
	 * @version 1.0.0.1
	 */
	@RequestMapping(value = "ajaxFindApplicationList", produces = { "application/json;charset=utf-8" })
	@ResponseBody
	public JSONObject ajaxFindApplicationList(ApplicationDto dto) {
		return adminApplicationService.ajaxFindApplicationList(dto);
	}
	
	
	
	/**
	 * @description: Dubbo项目部署节点列表
	 *
	 * @param dto.application 	服务名称
	 * @author Yangcl
	 * @date 2018年8月29日 下午5:01:37 
	 * @version 1.0.0.1
	 */
	@RequestMapping("page_application_dubbo_project_ip_list")
	public String pageApplicationDubboIpList(ApplicationDto dto , ModelMap model ,HttpSession session){
		model.put("application" , dto.getApplication());
		return "dubbo/admin/dubbo-project-ip-list";
	}
	
	/**
	 * @description: Dubbo项目部署节点列表数据集合
	 *			http://oms.ostar.com:8080/ostar-oms/application/ajaxFindDubboProjectIpList?application=OSTAR_OMS_SERVICE
	 *
	 * @param dto.application 	服务名称
	 * @author Yangcl
	 * @date 2018年8月29日 下午5:08:51 
	 * @version 1.0.0.1
	 */
	@RequestMapping(value = "ajaxFindDubboProjectIpList", produces = { "application/json;charset=utf-8" })
	@ResponseBody
	public JSONObject ajaxFindDubboProjectIpList(ApplicationDto dto) {
		return adminApplicationService.ajaxFindDubboProjectIpList(dto);
	}
	
	
	
	/**
	 * @description: Dubbo项目指定部署节点下的RPC接口类列表集合|jsp页面地址
	 *
	 * @param dto
	 * @param model
	 * @author Yangcl
	 * @date 2018年8月30日 下午3:14:52 
	 * @version 1.0.0.1
	 */
	@RequestMapping("page_application_dubbo_project_interface_list")
	public String pageApplicationDubboInterfaceList(ApplicationDto dto , ModelMap model ,HttpSession session){
		model.put("application" , dto.getApplication());
		model.put("nodeAddress" , dto.getNodeAddress());  
		return "dubbo/admin/dubbo-project-interface-list";
	}
	
	/**
	 * @description:  Dubbo项目指定部署节点下的RPC接口类列表集合|jsp页面数据集合
	 *			http://oms.ostar.com:8080/ostar-oms/application/ajaxFindDubboProjectInterfaceList?application=SCRM_BIZ_SERVICE&nodeAddress=10.12.51.141:20880
	 *
	 * @param dto.application 	服务名称					必填
	 * @param dto.nodeAddress 	host ip address		必填
	 * 
	 * @author Yangcl
	 * @date 2018年8月30日 下午3:28:14 
	 * @version 1.0.0.1
	 */
	@RequestMapping(value = "ajaxFindDubboProjectInterfaceList", produces = { "application/json;charset=utf-8" })
	@ResponseBody
	public JSONObject ajaxFindDubboProjectInterfaceList(ApplicationDto dto) {
		return adminApplicationService.ajaxFindDubboProjectInterfaceList(dto);
	}
}














































































