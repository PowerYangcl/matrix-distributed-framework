package cn.face.oms.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.alibaba.dubbo.common.Constants;
import com.alibaba.dubbo.common.URL;

import cn.face.oms.pojo.dto.ApplicationDto;
import cn.face.oms.pojo.view.ConsumerView;
import cn.face.oms.pojo.view.ProviderView;
import cn.face.oms.service.AbstractDubboAdminService;
import cn.face.oms.service.IAdminConsumerService;
import cn.face.oms.service.AbstractDubboAdminService.ConvertURL2Entity;
import cn.face.oms.utils.Pair;
import cn.face.oms.utils.SyncUtils;



/**
 * @description: dubbo admin consumer service
 *
 * @author Yangcl
 * @date 2018年8月27日 上午11:44:17 
 * @version 1.0.0.1
 */
@Service("adminConsumerService")
public class AdminConsumerServiceImpl extends AbstractDubboAdminService implements IAdminConsumerService {

	/**
	 * @description: 查询某个应用提供的所有消费信息
	 *
	 * @param dto.application 	服务名称
	 * @author Yangcl
	 * @date 2018年8月29日 下午5:15:52 
	 * @version 1.0.0.1
	 */
	public List<ConsumerView> listConsumerByApplication(ApplicationDto dto) {
		
		return super.filterCategoryData(
				new ConvertURL2Entity<ConsumerView>() {
		            public ConsumerView convert(Pair<Long, URL> pair) {
		            	
		                return SyncUtils.url2Consumer(pair);   
		            }
				} ,
				Constants.CONSUMERS_CATEGORY  , 	// consumers
				Constants.APPLICATION_KEY  , 			// application
				dto.getApplication()
			);
	}

}





















































