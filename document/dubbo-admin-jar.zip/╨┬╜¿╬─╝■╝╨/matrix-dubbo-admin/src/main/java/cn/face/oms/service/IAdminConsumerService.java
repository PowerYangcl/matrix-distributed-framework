package cn.face.oms.service;

import java.util.List;

import cn.face.oms.pojo.dto.ApplicationDto;
import cn.face.oms.pojo.view.ConsumerView;

public interface IAdminConsumerService {

	/**
	 * @description: 查询某个应用提供的所有消费信息
	 *
	 * @param dto.application 	服务名称
	 * @author Yangcl
	 * @date 2018年8月29日 下午5:15:52 
	 * @version 1.0.0.1
	 */
	public List<ConsumerView> listConsumerByApplication(ApplicationDto dto);

}
